import java.net.URL;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class ChatController {
	
	ChatClient chatClient;
	
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextArea areaDiscussion;

    @FXML
    private TextField entreeAdresseIP;

    @FXML
    private TextField entreeMessage;

    @FXML
    private TextField entreePort;

    @FXML
    private TextField entreePseudo;

    @FXML
    private Label labelEtatConnexion;

    @FXML
    void actionBoutonConnexion(ActionEvent event) {
    	//Erreur à tester
    	String addr = this.entreeAdresseIP.getText();
    	int port = Integer.parseInt(this.entreePort.getText());

    	chatClient.connectToServer(addr, port);
    	
    	
    }

    @FXML
    void actionBoutonDeconnexion(ActionEvent event) {
    	chatClient.deconnexion();
    }

    @FXML
    void actionBoutonEnvoyer(ActionEvent event) {
    	LocalTime heureActuelle = LocalTime.now();
    	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
    	String heureMinute = heureActuelle.format(formatter);
    	
    	String message = this.entreeMessage.getText();
    	String pseudo = this.entreePseudo.getText();
    	chatClient.envoyerMessage(new String("["+ heureMinute +"] "+pseudo + " : " + message));
    }
    
    void ajouterMessage(String message) {
    	areaDiscussion.appendText(message);
    }
    
    @FXML
    void initialize() {
        chatClient = new ChatClient(this);
        this.entreeAdresseIP.setText("localhost");
        this.entreePort.setText("5000");
    }

}
