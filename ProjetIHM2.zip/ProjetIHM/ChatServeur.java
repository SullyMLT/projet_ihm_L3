import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class ChatServeur {
	
	//La socket du serveur
	ServerSocket serverSocket;
	private static ChatServeur instance;
	//Le port

	List<ThreadServer> threads = new ArrayList<ThreadServer>();
	
	public void demarrerServeur(int port) {
		try {
			serverSocket = new ServerSocket(port);
			//En attente de connexion
			while (true) {
				
				Socket socket = serverSocket.accept();
				System.out.print("connexion ! \n");
				ThreadServer ts = new ThreadServer(socket, this);
				threads.add(ts);
				ts.start();
			}
		} catch (IOException e) {
			System.out.print("Problème lors du démarrage du serveur \n");
			e.printStackTrace();
		}
	}
	
	public void redistribuerMessage(Object message, ThreadServer tsSender) {
		System.out.print("Envoie d'un message sur tous les threads : " + message);
		System.out.println("Nombre de threads : " + threads.size());
		for (ThreadServer ts : threads) {
			ts.envoyerMessage(message);
		}
	}
	
	
	private class ThreadServer extends Thread{
		Socket socket; //Socket avec le client
		ObjectInputStream input;
		ObjectOutputStream output;
		ChatServeur parentInstance;
		public ThreadServer(Socket socket, ChatServeur parentInstance) {
			this.socket = socket;
			this.parentInstance = parentInstance;
			try {
	            this.output = new ObjectOutputStream(socket.getOutputStream());
	            this.input = new ObjectInputStream(socket.getInputStream());
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
		}
		
		
		public void envoyerMessage(Object message) {
		 	try {
	            output.writeObject(message);
	            output.flush();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
		}


		@Override
		public void run() {
		    try {
		    	//DEBLOQUE LE TRUC 
		    	//RECUPERE LE PREMIER MESSAGE
		    	Object firstLecture = input.readObject();
	            // Traiter les données reçues ici...
	            System.out.println("Données reçues : " + firstLecture);
		        while (socket.isConnected()) {
		            // Lire les données de manière asynchrone
		            Object receivedData = input.readObject();
		            
		            // Traiter les données reçues ici...
		            System.out.println("Données reçues : " + receivedData);
		            
		            // Simuler un traitement de données en attente
		            Thread.sleep(1000);
		            
		            this.parentInstance.redistribuerMessage(receivedData, this);
		            // Écrire des données de manière asynchrone
		            // Par exemple, vous pouvez avoir un mécanisme de réponse
		         
		            
		            // Simuler un traitement d'envoi de données
		            Thread.sleep(1000);
		        }
		        System.out.print("Fermeture du thread \n");
		        input.close();
		        output.close();
		        socket.close();
		    } catch (IOException | ClassNotFoundException | InterruptedException e) {
		        e.printStackTrace();
		    } finally {
		        // Fermer les flux et la connexion
		        try {
		            input.close();
		            output.close();
		            socket.close();
		        } catch (IOException e) {
		            e.printStackTrace();
		        }
		    }
		}
	}	
	
	
	public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Usage: java ServeurMonoClient <port>");
            return;
        }
        
        ChatServeur instance = new ChatServeur();
        
        instance.demarrerServeur(Integer.parseInt(args[0]));
	}
}
