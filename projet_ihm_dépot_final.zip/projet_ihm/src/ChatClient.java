import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.Socket;
import java.net.UnknownHostException;

import javafx.application.Platform;

public class ChatClient extends Thread {
  
  /**
   * La socket associée au client
   */
  protected Socket socket;
  
  /**
   * Le stream output pour envoyer des messages
   */
  protected ObjectOutputStream output;
  
  /**
   * Le stram input associé à la socket pour recevoir des messages
   */
  protected ObjectInputStream input;
  
  /**
   * L'instance du chatController pour pouvoir modifier l'interface
   */
  ChatController chatController;
  
  /**
   * Si le client est connecté à un serveur
   */
  boolean estConnecte;
  
  /**
   * Si le serveur sur lequel le client est connecté fonctionne correctement
   */
  boolean isServerAlive;
  
  /**
   * Si le serveur est en attente d'un multicast
   */
  boolean enAttenteMulticast;
  
  ThreadMulticast tm;
  
  /**
   * Constructeur de chat client
   * 
   * @param c l'instance de ChatController
   */
  public ChatClient(ChatController c) {
    this.chatController = c;
    estConnecte = false;
    enAttenteMulticast = false;
  }
  
  /**
   * Tente de connecter le client au serveur depuis une adresse et un port. Si
   * le client est déjà connecté à un serveur valide -> ne tente pas de le
   * connecter Si le client essaye de se connecter à une adresse multicast ->
   * démarre un thread qui attend de recevoir un potentiel packet Si l'addresse
   * passée en paramètre n'est pas valide -> renvoie une erreur Si le client
   * essaye de se connecter à un serveur valide -> démarre un thread d'écoute
   * des messages -> démarre un autre thread de ping qui ping le serveur toutes
   * les secondes pour voir si le serveur est en vie.
   * 
   * @param addr l'adresse de connexion.
   * @param port le port de connexion.
   */
  public void connectToServer(String addr, int port) {
    try {
      // Vérification que le port est correcte
      if (port < 0 || port > 65535) {
        chatController.afficherPopupErreur("Le port n'est pas valide");
        return;
      }
      
      // Si aucune socket n'est associé à l'instance
      if (socket == null && estConnecte == false) {
        // Tentative de création de socket à l'adresse et le port
        socket = new Socket(addr, port);
        // Création de l'outputStream pour envoyer des messages au serveur
        this.output = new ObjectOutputStream(this.socket.getOutputStream());
        // Envoie d'un premier message débloquant le stream côté serveur
        // Nécessaire sinon le prochain client se connecte doit attendre que
        // l'avant
        // dernier client
        // qui s'est connecté envoie un message
        String lecture = "Débloquage";
        output.writeObject(lecture);
        
        // Définit que le serveur est vivant
        setIsServerAlive(true);
        // Changement de l'état de connexion sur l'interface java FX
        chatController.changeEtatConnection(true,
            "Vous êtes connecté(e) au serveur");
        // Définit que l'instance est connecté à un serveur
        setEstConnecte(true);
        // Démarrage du thread d'écoute de message
        new ThreadClient(socket, this).start();
        // Démarrage du thread pour ping périodiquement le serveur
        new ThreadPingServer(this.output, this).start();
      } else {
        // Envoie sur l'interface un message d'erreur
        chatController.afficherPopupErreur("Vous êtes déjà connecté");
      }
      // Exception levée quand new Socket(addr, port) n'arrive pas à être créer
      // (IOException)
    } catch (IOException e) {
      try {
        
        // Récupération de l'adresse passé en argument et modification pour être
        // en
        // InetAddress
        InetAddress _addr = InetAddress.getByName(addr);
        // Vérification que l'adresse peut être multicast
        if (_addr.isMulticastAddress()) {
          // Changement sur l'interface que le client est actuellement entrain
          // d'attendre
          // un multicast
          this.chatController.labelEtatConnexion
              .setText("En attente Multicast");
          // Démarrage du Thread qui attend le packet
          tm = new ThreadMulticast(port, this, addr);
          tm.start();
        } else {
          // Si l'adresse n'est pas une adresse multicast, alors le serveur à
          // l'adresse
          // n'est pas disponible
          chatController
              .afficherPopupErreur("Le serveur à l'adresse est indisponible");
        }
        // Exception levée quand InetAddress.getByName(addr) renvoie une adresse
        // qui est
        // invalide.
      } catch (UnknownHostException e1) {
        // Affichage d'une erreur comme quoi l'adresse n'est pas valide
        chatController.afficherPopupErreur("L'adresse n'est pas valide");
      }
    }
  }
  
  /**
   * Envoie un message au serveur.
   * 
   * @param message le message à envoyer au serveur.
   */
  public void envoyerMessage(String message) {
    // Vérifie que la communication avec le serveur est possible
    if (socket == null || socket.isClosed() || !isServerAlive) {
      System.out.println("La socket est fermée");
      return;
    }
    
    try {
      // Si le stream output n'a jamais utilisé, le créer.
      if (this.output == null) {
        // N'est jamais atteint mais c'est pour question de surêté.
        this.output = new ObjectOutputStream(this.socket.getOutputStream());
        System.out.println("Connexion du stream");
      }
      System.out.println("Envoie du message au serveur");
      // Envoie du message au serveur par le stream
      output.writeObject(message);
      return;
      // Exception levée quand l'ObjectOutputStream est invalide. (unreachable
      // dans ce
      // cas)
    } catch (IOException e) {
      System.out.println("Erreur lors de l'envoi du message.");
      e.printStackTrace();
    }
    return;
  }
  
  /**
   * Gère la déconnexion si le client est connecté à un serveur.
   */
  public void deconnexion() {
    // Si la socket n'est pas nulle, par conséquent, le client est connecté.
    if (enAttenteMulticast) {
      enAttenteMulticast = false;
      chatController.labelEtatConnexion.setText("Déconnecté");
    }
    if (socket != null) {
      try {
        // Change l'état de connexion au serveur sur l'interface
        chatController.changeEtatConnection(false,
            "Vous avez été déconnecté du serveur");
        setEstConnecte(false);
        // Envoie un message au serveur précis
        // Le client ne peut pas envoyer "chaine" car le message d'un client est
        // de type
        // "[temps] : message"
        // Ce message permet au serveur de comprendre que la communication sur
        // cette
        // socket va être coupée.
        this.output.writeObject(new String("chaine"));
        // Ferme la socket
        socket.close();
        // Enlève la référence de la socket
        socket = null;
        System.out.println("Déconnecté");
        // Exception levée quand l'ObjectOutputStream est invalide. (unreachable
        // dans ce
        // cas)
      } catch (IOException e) {
        System.out.print("Le stream ne marche plus");
      }
      // Sinon, on part du principe que le client n'est connecté à un aucun
      // serveur
    } else {
      chatController
          .afficherPopupErreur("Vous êtes déjà déconnecté de tout serveur !");
    }
  }
  
  /**
   * Renvoie l'état de connexion du client.
   * 
   * @return l'état de connexion.
   */
  public boolean isConnected() {
    return this.estConnecte;
  }
  
  /**
   * Modifie l'état de validité du serveur.
   * 
   * @param isAlive le nouvel état de validité du serveur.
   */
  public void setIsServerAlive(boolean isAlive) {
    this.isServerAlive = isAlive;
  }
  
  /**
   * Modifie l'état de connexion du client.
   * 
   * @param _estConnecte le nouvel état de connexion du client.
   */
  public void setEstConnecte(boolean _estConnecte) {
    estConnecte = _estConnecte;
  }
  
  /**
   * Renvoie la socket de l'instance.
   * 
   * @return La socket.
   */
  public Socket getSocketChatClient() {
    return this.socket;
  }
  
  /**
   * Class qui gère l'attente potentiel d'un packet dans le cas où l'adresse
   * passée est une adresse multicast.
   */
  private class ThreadMulticast extends Thread {
    
    /**
     * La référence de la multicastSocket.
     */
    MulticastSocket multicastSocket;
    
    /**
     * L'instance qui a généré ce thread.
     */
    ChatClient parentInstance;
    
    /**
     * Constructeur du thread, reçoit le port, ainsi que l'adresse et l'instance
     * parentale.
     * 
     * @param port le port demandé.
     * @param parentInstance l'instance parentale.
     * @param addr l'adresse demandée.
     */
    @SuppressWarnings("deprecation")
    public ThreadMulticast(int port, ChatClient parentInstance, String addr) {
      try {
        // Créer la MulticastSocket sur le port demandé
        this.multicastSocket = new MulticastSocket(port);
        this.parentInstance = parentInstance;
        // Rejoint le groupe sur l'adresse modifié en InetAddress d'addr
        this.multicastSocket.joinGroup(InetAddress.getByName(addr));
        // Exception levée quand le port n'est pas valide et/ou que l'addresse
        // ne l'est
        // pas non plus
      } catch (IOException e) {
        System.out.print("erreur dans le constructor");
        e.printStackTrace();
      }
      
    }
    
    /**
     * La fonction runnable qui est implémenté par Thread permet d'attendre de
     * recevoir le packet UDP contenant l'ip et le port du serveur. Ce thread
     * reste actif jusqu'à recevoir un paquet ou jusqu'à ce que le client se
     * déconnecte.
     */
    public void run() {
      System.out.print(
          "En attente d'un possible multicast : " + multicastSocket.toString());
      this.parentInstance.enAttenteMulticast = true;
      byte[] buffer = new byte[256];
      DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
      try {
        // Récupère le packet
        multicastSocket.receive(packet);
        // Traitement des données reçues
        String message = new String(packet.getData(), 0, packet.getLength());
        // Split le message : car le message envoyé est "ip : port"
        String[] parts = message.split(":");
        // Récupère l'ip
        String serverIPAddress = parts[0];
        // Récupère le port
        int serverPort = Integer.parseInt(parts[1]);
        System.out.print("Récuperer le packet : " + message);
        if (this.parentInstance.enAttenteMulticast) {
          Platform.runLater(() -> {
            // Tente de relancer connectToServer à partir des nouvelles
            // informations
            this.parentInstance.connectToServer(serverIPAddress, serverPort);
          });
        }
        
        // Exception levée pour receive, si le multisocket n'est pas
        // correctement agencé
      } catch (IOException e) {
        System.out.print("erreur dans le run");
        e.printStackTrace();
      }
      
    }
  }
  
  /**
   * Class qui ping le serveur toutes les secondes pour vérifier que le serveur
   * est vivant.
   */
  private class ThreadPingServer extends Thread {
    
    /**
     * L'outputStream associé à la socket.
     */
    ObjectOutputStream output;
    /**
     * L'instance qui a générée ce Thread.
     */
    ChatClient chatClient;
    
    /**
     * Constructeur de ThreadPingServer qui permet de détecter si le serveur est
     * toujours connecté au client.
     * 
     * @param output l'instance ObjectOutputStream du parent.
     * @param chatClient instance parentale.
     */
    public ThreadPingServer(ObjectOutputStream output, ChatClient chatClient) {
      this.output = output;
      this.chatClient = chatClient;
    }
    
    /**
     * Vérifie que le serveur est vivant en envoyant un message "ping" toutes
     * les secondes au serveur Si une exception est levée, alors le serveur
     * n'est plus disponible.
     */
    public void run() {
      
      while (isServerAlive) {
        
        try {
          // Envoie du ping
          this.output.writeObject("ping");
          // Dors pendant 1 seconde
          Thread.sleep(1000);
          // Exceptions levées quand le thread est interrupted (n'arrive jamais)
          // et quand
          // this.output ne fonctionne plus
        } catch (IOException | InterruptedException e) {
          // Modifie l'état du serveur
          this.chatClient.setIsServerAlive(false);
          // Si le client est encore connecté
          if (socket != null) {
            // Déconnexion du client au serveur
            Platform.runLater(() -> {
              this.chatClient.chatController.changeEtatConnection(false,
                  "Plus de contact avec le serveur");
              
            });
            this.chatClient.socket = null;
            this.chatClient.estConnecte = false;
          }
          // Quitte la boucle
          break;
        }
      }
    }
  }
  
  /**
   * Class qui hérite de thread qui permet l'écoute des messages.
   */
  private class ThreadClient extends Thread {
    
    /**
     * La socket connecté au serveur.
     */
    Socket socket;
    
    /**
     * L'input stream pour lire les messages.
     */
    ObjectInputStream input;
    
    /**
     * l'instance parentale.
     */
    ChatClient chatClient;
    
    /**
     * Constructeur qui génère le stream d'écoute.
     * 
     * @param socket la socket associée.
     * @param cc l'instance parentale.
     */
    public ThreadClient(Socket socket, ChatClient cc) {
      this.socket = socket;
      this.chatClient = cc;
      try {
        this.input = new ObjectInputStream(socket.getInputStream());
        // Exception levée si la socket est invalide
      } catch (IOException e) {
        System.out.print("Problème lors de la création de l'inputStream");
        e.printStackTrace();
      }
    }
    
    /**
     * Positionne le thread sur l'écoute des messages A chaque fois qu'il reçoit
     * un message, il l'ajoute sur l'interface graphique.
     */
    public void run() {
      
      /**
       * Tant que la socket est connecté et que le serveur est fonctionnel.
       */
      while (socket.isConnected() && isServerAlive) {
        System.out.print("En Attente d'un message \n");
        try {
          // Lit le message
          String message = (String) input.readObject();
          if (message == null) {
            break; // Sortir de la boucle si le serveur se déconnecte
          }
          // ajoute le message à l'interface graphique
          this.chatClient.chatController.ajouterMessage(message + "\n");
          
          // Exception levée si l'input est invalide (socket close)
        } catch (ClassNotFoundException | IOException e) {
          break;
        }
      }
    }
    
  }
  
}
