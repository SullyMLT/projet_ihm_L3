package chat;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashSet;
import java.util.Set;

public class ConversationChat implements Runnable {
  Socket socket = null;
  OutputStream outputStream = null;
  InputStream inputStream = null;
  String msg = "";
  // Stocke les clients en cours d'execution
  Set<ConversationChat> clients = new HashSet<ConversationChat>();
  
  public ConversationChat(Socket socket) {
    this.socket = socket;
  }
  
  // Met à jour les clients s'il y en a des nouveaux
  public void updateClient(Set<ConversationChat> clientFromServer) {
    this.clients.addAll(clientFromServer);
  }
  // retourne la chaine de caractère reçu
  public String receiveMsg(Socket socket) {
    
    try {
      inputStream = socket.getInputStream();
    } catch (IOException e) {
      e.printStackTrace();
    }
    byte[] buffer = new byte[250]; // Taille de la chaine de caractère max 250
    try {
      inputStream.read(buffer);
    } catch (IOException e) {
      e.printStackTrace();
    }
    String msg = new String(buffer);
    
    return msg;
  }
  
  // Méthode envoyant une chaine de caractère au socket cible
  public void reSendMessage(Socket socket, String msg) {
    
    try {
      outputStream = socket.getOutputStream();
    } catch (IOException e) {
      System.out.println("Préparation envoie message");
      e.printStackTrace();
    }
    try {
      outputStream.write(msg.getBytes());
    } catch (IOException e) {
      System.out.println("Envoie message");
      e.printStackTrace();
    }
  }
  
  @Override
  public void run() {
    while (true) {
      // récupère la chaine dans msg
      this.msg = receiveMsg(this.socket);
      // la renvoie à tout les clients actuellement connecté
      for(ConversationChat cc : this.clients) {
        reSendMessage(cc.socket, this.msg);
      }
      System.out.println(this.msg);
    }
  }
}