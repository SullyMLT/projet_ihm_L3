package chat;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class ClientChat {
  
  OutputStream output = null;
  InputStream input = null;
  
  
  public ClientChat() {
    
  }
  
  //ClientChat clientChat = new ClientChat();
  
  public Socket connectServer(String addr, int port) {
    // adresse IP du serveur
    InetAddress adr = null;
    try {
      adr = InetAddress.getByName(addr);
    } catch (UnknownHostException e) {
      e.printStackTrace();
    }
    // ouverture de connexion avec le serveur sur le port 7777
    Socket socket = null;
    try {
      socket = new Socket(adr, port);
    } catch (IOException e) {
      e.printStackTrace();
    }
    return socket;
  }
  // permet d'envoyé le message au serveur cible
  public void sendMessage(Socket socket, String msg) {
    
    try {
      output = socket.getOutputStream();
    } catch (IOException e) {
      System.out.println("Préparation envoie message");
      
      e.printStackTrace();
    }
    try {
      output.write(msg.getBytes());
    } catch (IOException e) {
      System.out.println("Envoie message");
      e.printStackTrace();
    }
  }
  
  // return la chaine de caractère du message recu par le client
  public String receiveMsg(Socket socket) {
    
    try {
      input = socket.getInputStream();
    } catch (IOException e) {
      e.printStackTrace();
    }
    byte[] buffer = new byte[250]; // Taille de la chaine de caractère max 250
    try {
      input.read(buffer);
    } catch (IOException e) {
      e.printStackTrace();
    }
    String msg = new String(buffer);
    
    return msg;
  }
  
  public void disconnect(Socket socket) {
    try {
      input.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
    
    try {
      output.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
    
    try {
      socket.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
  
}
