package chat;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashSet;
import java.util.Set;

public class ServerChat {
  String msg;
  ServerSocket serverSocket;
  ConversationChat conversationChat;
  Set<ConversationChat> clients = new HashSet<ConversationChat>();
  
  
  public ServerChat() {
    
  }
  
  public void onServer(int port) {
    ServerSocket serverSocket = null;
    try {
      serverSocket = new ServerSocket(port);
      System.out.println("Demarrage serveur");
    } catch (IOException e) {
      System.out.println("Erreur demarrage server");
      e.printStackTrace();
    }
    // Tant que le serveur est ouvert on accepte de nouveaux clients
    while (!(serverSocket.isClosed())) {
      Socket socket = null;
      try {
        socket = serverSocket.accept();
        System.out.println("Nouvelle Connexion !");
      } catch (IOException e) {
        e.printStackTrace();
      }
      // Créer un thread pour chaque client
      conversationChat = new ConversationChat(socket);
      Thread thread = new Thread(conversationChat);
      this.clients.add(conversationChat);
      thread.start();
      
      for (ConversationChat cc : this.clients) {
        cc.updateClient(this.clients);
      }
    }
    disconnectServer(serverSocket);
  }
  
  public void disconnectServer(ServerSocket serverSocket) {

      try {
        serverSocket.close();
      } catch (IOException e) {
        e.printStackTrace();
      }

  }
  
  public static void main(String[] args) {
    
    ServerChat serverChat = new ServerChat();
    if (args.length == 1) {
      serverChat.onServer(Integer.parseInt(args[0]));
    }
  }
}
