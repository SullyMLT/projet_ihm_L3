package ui;

import chat.ClientChat;
import java.io.IOException;
import java.net.Socket;
import java.net.URL;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class ChatController {
  
  @FXML
  private ResourceBundle resources;
  
  @FXML
  private URL location;
  
  @FXML
  private TextArea areaDiscussion;
  
  @FXML
  private TextField entreeAdresseIP;
  
  @FXML
  private TextField entreeMessage;
  
  @FXML
  private TextField entreePort;
  
  @FXML
  private TextField entreePseudo;
  
  @FXML
  private Label labelEtatConnexion;
  
  ClientChat clientChat = new ClientChat();
  
  Socket socketClient;
  
  @FXML
  void actionBoutonConnexion(ActionEvent event) {
    socketClient = clientChat.connectServer(entreeAdresseIP.getText(),
        Integer.parseInt(entreePort.getText()));
    
    labelEtatConnexion.setText("Connecté");
  }
  
  @FXML
  void actionBoutonDeconnexion(ActionEvent event) {
      clientChat.disconnect(socketClient);
      
      labelEtatConnexion.setText("Non connecté");

  }
  
  @FXML
  void actionBoutonEnvoyer(ActionEvent event) {
    LocalTime heureActuelle = LocalTime.now();
    
    // Formatter pour afficher uniquement l'heure et les minutes
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
    
    // Formater l'heure actuelle
    String heureMinute = heureActuelle.format(formatter);
    if (!(entreeMessage.getText().equals(""))) {
      
      String msgToSend = "[" + heureMinute + "] " + entreePseudo.getText()
          + " : " + entreeMessage.getText();
      clientChat.sendMessage(socketClient, msgToSend);
      String msg = clientChat.receiveMsg(socketClient);
      areaDiscussion.appendText(msg + "\n");
      entreeMessage.clear();
      
    }
  }
  
  @FXML
  void initialize() {
    entreeAdresseIP.setText("localhost");
    entreePort.setText("5455");
  }
  
}
